<?php require '../layout/header.php' ?>
<h1>Danh sách sinh viên</h1>
<a href="create.php" class="btn btn-info">Add</a>
<form action="list.html" method="GET">
    <label class="form-inline justify-content-end">Tìm kiếm: <input type="search" name="search" class="form-control"
            value="">
        <button class="btn btn-danger">Tìm</button>
    </label>
</form>
<table class="table table-hover">
    <thead>
        <tr>
            <th>#</th>
            <th>Mã SV</th>
            <th>Tên</th>
            <th>Ngày Sinh</th>
            <th>Giới Tính</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php
        require '../config.php';
        require '../connectDb.php';
        $sql = "SELECT * FROM student";
        $result = $conn->query($sql);
        $order = 0;
        if ($result->num_rows > 0) :
            while ($row = $result->fetch_assoc()) :
                $order++;
        ?>
        <tr>
            <td><?= $order ?></td>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['birthday'] ?></td>
            <td><?= $row['gender'] ?></td>
            <td><a href="edit.html">Sửa</a></td>
            <td><a data="1" class="delete" href="list.html" type="student">Xóa</a></td>
        </tr>
        <?php
            endwhile;
        endif;
        ?>
    </tbody>
</table>
<div>
    <span>Số lượng: <?= $order ?></span>
</div>
<?php require '../layout/footer.php' ?>