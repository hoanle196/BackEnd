<script src="../public/vendor/jquery-3.5.1.min.js"></script>
<script src="../public/vendor/popper.min.js"></script>
<script src="../public/vendor/bootstrap-4.5.3-dist/js/bootstrap.min.js"></script>
<script src="../public/js/script.js"></script>
</div>
</body>

</html>