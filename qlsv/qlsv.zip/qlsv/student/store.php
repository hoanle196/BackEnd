<?php
//Dữ liệu trong $_POST sẽ được lưu xuống bảng student của database
var_dump($_POST);