<?php
//Chạy tới, điều hướng đến thư mục student
//Mặc định sẽ chạy file index.php trong thư mục student
header('location:student');